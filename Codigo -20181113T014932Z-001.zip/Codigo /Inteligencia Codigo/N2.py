import textblob 
from textblob import Word
from textblob import TextBlob
import Proyecto
import CreaArchivos
from stop_words import get_stop_words

from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import numpy as np
from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist

stop = get_stop_words('english')


archivo= open('gp2.txt', 'r').read()#la base de datos
neg = open('negative-words.txt', 'r').read()
pos = open('positive-words.txt', 'r').read()
positivas = CreaArchivos.palabrasPositivas()#crea las palabras positivas
negativas = CreaArchivos.palabrasNegativas()#crea las palabras negativas
arc = archivo.decode('utf8')
#arc =archivo
palabras = Proyecto.vectorPalabras(arc)#palabras quer hay en la base
plaN =Proyecto.vectorPalabras(neg)
plaP = Proyecto.vectorPalabras(pos)


for i in plaP:
	positivas.append(i)

for i in plaN:
	negativas.append(i)


 

def vectorPalabras(texto):
	#te = texto.encode('utf8')
	text = [i for i in texto.lower().split() if i not in stop]
	return text


todas = vectorPalabras(arc)
print archivo.find('will')
print archivo.count('will')

for i in positivas:
		if ('.' in positivas or ',' in positivas or ':' in positivas or '#' in positivas or len(i)<=1 ):
			positivas.remove(i)




"""for i in positivas:
	print i , "es i  en positivos"
	a = i.decode('utf8')
	b= a.lower()
	print b
	if (b in arc):
		print arc.count(b)
"""





plt.subplot(1,2,1)

#prueba
#j=0.1
#k=0.1
array=np.zeros((len(palabras),2))#creas una matriz 
#8 seria el numero de palabras sin repetir de tu array

"""
print 'veces con las que aparece si'
print nom2.count('si') 
"""

#recorremos el arreglo nom
for i in range(len(palabras)):
	#le decimos que si las palabras estan en la base de datos 
	#con palabras buenas

	if(todas[i] in positivas):
		
		#print j
		#si esta contamos las veces que la palabra en el array de
		#donde estan todas las palabras
		s=todas[i].lower()
		print s
		a=todas.count(s)#te regresa un int las veces que aparece
		
		if(a==0):
			#si esa palabra solo aparece una vez le ponemos que su peso es 1.9
			array[i,0]=1.9
		else:
			array[i,0]=a #sino le asignamos el numero de veces que se repite
		#j=j+0.1
		#print j
		#print i
	else :
		#repetimos lo de antes pero si la palabra cae en la base de datos mala
		if(todas[i] in negativas):
			
			s=todas[i].lower()
			
			b=todas.count(s)
			if(b==0):
				array[i,1]=1.9
			else:
				array[i,1]=b
			#k=k+0.1
			#print i
		else:
			#si no esta en ninguna es neuntra y lo dejamos en default con 0
			#print 'esta en neutro'
			print i
		
#print array
plt.xlabel('Positivo')
plt.ylabel('Negativo')
plt.scatter(array[:,0],array[:,1],s=75,alpha=.5)

for i in range(len(array)):
	plt.annotate(todas[i],xy=(array[i,0],array[i,1]))


plt.subplot(1,2,2)
data_dist=pdist(array,'euclidean')
print data_dist
data_link=linkage(data_dist)
dendrogram(data_link,labels=palabras,orientation="right")

#data_dist=pdist(a,'euclidean')
	#data_dist=pdist(a,'cityblock')
	#data_dist=pdist(a,'chebyshev')

plt.show()

