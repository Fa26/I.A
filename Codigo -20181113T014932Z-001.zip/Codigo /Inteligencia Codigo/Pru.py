from matplotlib import pyplot as plt

from scipy.cluster.hierarchy import dendrogram, linkage

import numpy as np

from scipy.cluster.hierarchy import cophenet

from scipy.spatial.distance import pdist

plt.subplot(1,4,1)



nombres=['disagree','welcomed','president-elect','chance','trump','good']



a=np.array([[12,0,0,3,3,1], [1,0,2,2,2,2],[0,14,6,2,3,0],[2,0,0,0,0,0],[0,15,0,0,0,0],[1,1,0,0,0,0]])

print a.shape

plt.scatter(a[:,0],a[:,1])

print len(a)



plt.subplot(1,4,2)



nombres=['disagree','welcomed','president-elect','chance','trump','good']



a=np.array([[12,0,0,3,3,1], [1,0,2,2,2,2],[0,14,6,2,3,0],[2,0,0,0,0,0],[0,15,0,0,0,0],[1,1,0,0,0,0]])

print a.shape

plt.scatter(a[:,0],a[:,1])

print len(a)

for i in range(len(a)):

	plt.annotate(nombres[i],xy=(a[i,0],a[i,1]))



#bien

plt.subplot(1,4,3)

print 'cluster 3'

nombres=['disagree','welcomed','president-elect']

a=np.array([[0,35], [10,0],[0,0]])

plt.scatter(a[:,0],a[:,1])

print len(a)

print a.shape

for i in range(len(a)):

	plt.annotate(nombres[i],xy=(a[i,0],a[i,1]))



#bien

plt.subplot(1,4,4)

a=np.array([[0,35], [16,0],[0,0]])
print a , "es  a"

nombres=['disagree','welcomed','president-elect']

data_dist=pdist(a,'cityblock')

print data_dist

data_link=linkage(data_dist)

dendrogram(data_link,labels=nombres,orientation="right")





plt.show()