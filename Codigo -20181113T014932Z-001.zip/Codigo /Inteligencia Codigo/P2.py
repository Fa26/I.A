
from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import numpy as np
from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist


#bien
plt.subplot(1,3,1)
print 'cluster 3'
nombres=['disagree','welcomed','president-elect','chance','good']
a=np.array([[0,35], [10,0],[0,0],[5,0],[7,0]])
plt.scatter(a[:,0],a[:,1])
print len(a)
print a.shape
for i in range(len(a)):
	plt.annotate(nombres[i],xy=(a[i,0],a[i,1]))


plt.subplot(1,3,2)
print 'cluster 3'
nombres=['disagree','welcomed','president-elect','chance','good']

a=np.array([[0,35], [10,0],[0,0],[5,0],[7,0]])
plt.scatter(a[:,0],a[:,1])
print len(a)
print a.shape





#bien
plt.subplot(1,3,3)
a=np.array([[0,35], [16,0],[0,0],[5,0],[7,0]])
nombres=['disagree','welcomed','president-elect','chance','good']
data_dist=pdist(a,'euclidean')
print data_dist
data_link=linkage(data_dist)
dendrogram(data_link,labels=nombres,orientation="right")


plt.show()