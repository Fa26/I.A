

from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import numpy as np
from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist

plt.subplot(1,2,1)#divide la ventana en una fila y dos columnas
#generarndo clusterings

#etiquetas
nombres=['A','B','C','D','E']
#nombres=['A','B','C','D']
#nombres=['A','B','C','D','E','F','G']
#nombres=['estuvo','aburrida','lenta','dramatica','tediosa']

#a=np.array([[1,1,0,0,0],[1,1,1,0,0],[1,1,0,1,0],[1,1,0,0,1]])
a=np.array([[0,0,0,0,0],[1,0,0,0,0],[5,4.5,0,0,0],[8.5,7.8,3.6,0,0],[7.2,6.7,2.2,2,0]])
#a=np.array([[0,1,4,5],[0,0,2,6],[0,0,0,3],[0,0,0,0]])
#a=np.array([[0,0,0,0,0,0,0],[2.15,0,0,0,0,0,0],[0.7,1.53,0,0,0,0,0],[1.07,1.14,0.43,0,0,0,0],
	#[0.85,1.38,0.21,0.29,0,0,0],[1.16,1.01,0.55,0.22,0.41,0,0],[1.56,2.83,1.86,2.04,2.02,2.05,0]])
#a=np.array([[0,0,0,0],[9,0,0,0],[4,5,0,0],[7,3,11,0]])
#a=np.array([[1,0,0,0,0],[0.39,1,1,1,1],[0.75,0.24,1,0,0],[0.56,0.63,0.42,1,0],[0.81,0.72,0.12,0.93,1]])

print a.shape

#muestra todos los puntos
plt.scatter(a[:,0],a[:,1])

print len(a)

#plt.annotate(nombres[0],xy=(0,0))
#plt.annotate(nombres[0],xy=(a[0,0],a[0,1]))
#plt.annotate(nombres[1],xy=(1,0))
#plt.annotate(nombres[2],xy=(5,4.5))
#plt.annotate(nombres[3],xy=(8.5,7.8))	
#plt.annotate(nombres[4],xy=(7.2,6.7))		

#etiqueta cada punto en el clsutering
for i in range(len(a)):
	plt.annotate(nombres[i],xy=(a[i,0],a[i,1]))




	
#grafica dendograma
#divide la ventana en una fila y dos columnas
plt.subplot(1,2,2)
data_dist=pdist(a,'euclidean')
data_link=linkage(data_dist)
dendrogram(data_link,labels=nombres)
#dendrogram(data_link,labels=nombres,orientation="right")
plt.show()




