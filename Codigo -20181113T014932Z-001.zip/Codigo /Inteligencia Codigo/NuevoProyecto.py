#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pickle
import nltk 
import nltk.data
import xlrd
import CreaArchivos
import Proyecto



from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import numpy as np
from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist	
from stop_words import get_stop_words
from nltk.corpus import stopwords # bibliotca de tekenizer
#from nltk.book import *


from stop_words import get_stop_words
from numpy import *
from Tkinter import *
import nltk 
#import Stemmer
from nltk.stem import SnowballStemmer
english_stemmer = SnowballStemmer("english")
stop = get_stop_words('english')


def contar_veces(self, elemento, lista):
    veces = 0
    for i in lista:
        if elemento == i:
       		veces += 1
    return veces



def eliminar_repetidos(palabras):#elimina palabras repetidas
	nueva=[]
	for elemento in palabras:
		if not elemento in nueva:
			nueva.append(elemento)
		if(len(elemento) <=2 ):
			nueva.remove(elemento)
	return nueva


def listPalabras(positivas, palabras):
	p=[]
	for pa in positivas:
		for pala in palabras:
			s=str(pa)
			if(s.find(pala.upper()) != -1):
				
				p.append(pala)
		
	return p

def listPalabrasNeg(negativas, palabras):
	p=[]

	for ne in negativas:
		for pal in palabras:
			s=str(ne)
			if(s.find(pal.upper()) != -1):
				p.append(pal)
	return p


def arreglo(lp,ln, pal):
	p=[]


if __name__ == "__main__":


	vector=[]
	archivo= open('vector1.txt', 'r').read()#la base de datos
	positivas = CreaArchivos.palabrasPositivas()#crea las palabras positivas
	negativas = CreaArchivos.palabrasNegativas()#crea las palabras negativas

	palabras = Proyecto.vectorPalabras(archivo)#palabras quer hay en la base
	

	arc = archivo.decode('utf8')

	pas = Proyecto.vectorPalabras(arc)

	toke = nltk.word_tokenize(arc)#separa por palabras
	print "es el  type ", type(toke)
	print type(toke) , "es rootototot"
	text = [i for i in toke if i.lower() not in stop]
	palabrasRaiz = [english_stemmer.stem(t) for  t in text]
	#palRaiz = eliminar_repetidos(palabrasRaiz)
	for i in palabrasRaiz:
		if ('.' in palabrasRaiz or ',' in palabrasRaiz or ':' in palabrasRaiz or '#' in palabrasRaiz or len(i)<=1 ):
			palabrasRaiz.remove(i)

	pal = eliminar_repetidos(palabrasRaiz)


	


	listPos=listPalabras(positivas, pal)#lista depalabras  que se encuentran y son positivas
	listNeg=listPalabrasNeg(negativas, pal)#lsiata depalabras que son negativas
	lp =eliminar_repetidos(listPos)#lista de raiz de palabras positivas
	ln = eliminar_repetidos(listNeg)#lista de raiz de palabras negativas

print text[len(text)-6]	




"""

	for i in range(len(lp)):
		if(lp[i].find('welc') != -1):

			print "si se enccintra  akak"	
			print lp[i], "essss" , i


	print lp[86] , "es  su tamño",len(lp), " es el typo ", type(lp[85])

	num=0
	for i in range(len(palabras)):		
		if(palabras[i].find('welc') != -1):
			num = num+1

	pv = lp[85]
	pp = pv.decode('utf8')	
	print palabras[3] , "222222222222222222"		
	print archivo.count(pp), " es le  welcome  con pc "		

	print  num , "es un num num num"

	for i in range(8):
		print palabras[i] ," es pal"
		if(palabras[i].find('welc') != -1):
			print palabras.count(palabras[i]), "es  el contador"
			print palabras[i], "espalabra"
"""

	
	#"print arc.count(listPos[0]) , "es el numero de positivosoasdas"


