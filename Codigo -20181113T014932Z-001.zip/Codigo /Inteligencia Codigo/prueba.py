#!/usr/bin/env python
# -*- coding: utf-8 -*-
from textblob import TextBlob

wiki = TextBlob("ESpero que si funciones en español esta bien")
wiki.tags

