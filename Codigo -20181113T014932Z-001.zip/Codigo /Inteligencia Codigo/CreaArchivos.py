#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xlrd
book = xlrd.open_workbook("inquirerbasic.xls")
sh = book.sheet_by_index(0)
#print sh.name, sh.nrows, sh.ncols
#print "Cell (2,0) is: ", sh.cell_value(rowx=0, colx=2)


def palabrasPositivas():
	pos= []
	for r in range(sh.nrows):
		if (sh.cell_value(rowx=r, colx=2) == 'Positiv'):
			pos.append(sh.cell_value(rowx=r, colx=0))

	return pos

def palabrasNegativas():
	neg = []
	for r in range(sh.nrows):
		if (sh.cell_value(rowx=r, colx=3) == 'Negativ'):
			neg.append(sh.cell_value(rowx=r, colx=0))

	return neg


neg = palabrasNegativas()
pos = palabrasPositivas()
ss= 'well'.upper()

print type(neg[4])
print neg[4]
n = neg[3].decode('utf8')
print type(n) , "wew"

print neg[3].find('a'), "es"



