#!/usr/bin/env python
# -*- coding: utf-8 -*-



from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import numpy as np
from scipy.cluster.hierarchy import cophenet
from scipy.spatial.distance import pdist	







import pickle
import nltk 
import nltk.data
import xlrd
import CreaArchivos


from stop_words import get_stop_words
from nltk.corpus import stopwords # bibliotca de tekenizer
from numpy import *
from nltk.tokenize import * # bibliotca de tekenizer
from Tkinter import * # bibliotca de tekenizer
from tokenize import *# bibliotca de tekenizer
#from nltp.tokenize import *
from nltk import *# bibliotca de tekenizer
from nltk.corpus import * # bibliotca de tekenizer
#from nltk.book import * 
from nltk.tokenize.mwe import MWETokenizer # bibliotca de tekenizer

from Tkinter import *



tokenizer = TreebankWordTokenizer ()
#stop = set(stopwords.words('English'))
stop = get_stop_words('english')

archivo= open('vector1.txt', 'r').read()




def vectorPalabras(texto):
	#te = texto.encode('utf8')
	text = [i for i in texto.lower().split() if i not in stop]
	
	frases=texto.splitlines() # parte cada vez que hayaun salto de linea y el numero de vectores
	palabrasSpl = eliminar_repetidos(text)
	return palabrasSpl
	

def analistasSplit(texto):
	text = [i for i in texto.lower().split() if i not in stop]
	frases=texto.splitlines() # parte cada vez que hayaun salto de linea y el numero de vectores
	
	palabrasSpl = eliminar_repetidos(text)
	
	vectores = [cuenta(frase, palabrasSpl)for frase in frases]
	return vectores


def funcion():
	t = lineas.get('1.0', 'end')
	palabras = vectorPalabras(t)#Regresa el vector con las palabras
	vectores = analistasSplit(t)#con el metodo con split
	vvv = analisaTokeniza(t)# analiza con el metodo de tokens
	palabrasT = vectorPalabrasT(t)#Regresa el arreglod e palabras con la biblioteca  token
	#print palabras
	#print vectores
	Cluster(palabras, vectores)
	return vectores


def analisaTokeniza(texto):
	frases=texto.splitlines() # parte cada vez que hayaun salto de linea y el numero de vectores
	palabrasToke = tokenizer.tokenize (texto)
	palabraSR = eliminar_repetidos(palabrasToke)
	vectores = [cuenta(frase, palabraSR)for frase in frases]
	return vectores

def vectorPalabrasT(texto):
	frases=texto.splitlines() # parte cada vez que hayaun salto de linea y el numero de vectores
	
	palabrasToke = tokenizer.tokenize (texto)
	palabraSR = eliminar_repetidos(palabrasToke)
	return palabraSR



def eliminar_repetidos(palabras):#elimina palabras repetidas
	nueva=[]
	for elemento in palabras:
		if not elemento in nueva:
			nueva.append(elemento)
	return nueva


def cuenta (frases, palabras):#nos de el numeor de apariciones de las palabras en la frase
	return [frases.count(palabra) for palabra in palabras ]






#-------------------------------------------------


def Cluster(palabras, vectores):
	

	a=np.array(vectores)
	
	data_dist=pdist(a,'euclidean')
	#data_dist=pdist(a,'cityblock')
	#data_dist=pdist(a,'chebyshev')
	data_link=linkage(data_dist)
	dendrogram(data_link, labels=palabras)
	#dendrogram(data_link,labels=palabras, truncate_mode="level", orientation="right")
	plt.show()












"""
#Aqui se crea la ventana
ventana = Tk()
ventana.geometry("520x430")#Tamaños de la ventan principal
ventana.title("Analisis de sentimientos")#Titulo de la ventana
comentarios = StringVar()
lineas = Text(ventana, height=25, width=70 , bd=3) # es para que puedas insertar varias lineas de texto
lineas.pack()
boton =Button(ventana, text="Analizar", command=funcion)
boton.pack()
ventana.mainloop() # Se inicia la ventana
"""




if __name__ == "__main__":


	positivas = CreaArchivos.palabrasPositivas()
	negativas = CreaArchivos.palabrasNegativas()
	print len(positivas) , "Tamaño de palabras psoitivas"
	print len(negativas) , "Tamaño de palabras NEgativas"

	
	arc = archivo.decode('utf8')
	palabras = vectorPalabras(arc)
	pos =0
	neg =0
	print positivas
	for p in palabras:
		if(p.upper() in positivas or p.upper(),"#1" in positivas):
			print p , "son positivas"
			pos = pos+1
	
	for le in palabras:
		if(le.upper() in negativas or le.upper(),"#1" in negativas):
			print le , " son Negarivas"
			neg = neg+1
	
		
	print pos, "es le nuemro de palabras positivas"
	print neg , "Es el numero de palabras negativas"

	if ('WAY' in positivas or 'WAY','#1' in positivas ):
		print "Si s eenceuntra la palabra"
	#palabrasDe =[palabra.decode('utf8') for  palabra in palabras]
	#palabrasDe = palabras.decode('utf8')
	#palabrasEn =[palabra.encode('utf8') for  palabra in palabras]
	#palabrasEn = palabrasDe.encode('utf8')
	vectores = analistasSplit(archivo)
	
	Cluster(palabras, vectores)


